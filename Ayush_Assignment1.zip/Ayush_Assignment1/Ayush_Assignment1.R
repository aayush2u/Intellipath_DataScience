getwd()
setwd("F:/RStudio")

#Q1.
a = c(4,17,7,4,6,8,9,15,17,20)

#a)
mean(a)

#b)
a1=sort(a)
str(a1)
Amedian=(a1[5]+a1[6])/2
Amedian
median(a)

#c)
a2=table(a)
a2
names(a2)[which(a2==max(a2))]

amode=names(table(a))[table(a)==max(table(a))]
amode

#d)

a3=c(a[1]-mean(a),a[2]-mean(a),a[3]-mean(a),a[4]-mean(a),a[5]-mean(a),a[6]-mean(a),a[7]-mean(a),a[8]-mean(a),a[9]-mean(a),a[10]-mean(a))
a
a3
avariance=((a3[1]^2)+(a3[2]^2)+(a3[3]^2)+(a3[4]^2)+(a3[5]^2)+(a3[6]^2)+(a3[7]^2)+(a3[8]^2)+(a3[9]^2)+(a3[10]^2))/10
avariance

#there is diffrnce between what i calculated and what var funbction calculated, please suggest.
var(a)

#e)
sd(a)


#Q2.

b=matrix(21:29,nrow = 3,ncol = 3)
b
#a)
diag(b)

#b)
lower.tri(b, diag = TRUE)

#c)
lower.tri(b, diag = FALSE)

#d)
upper.tri(b, diag = TRUE)

#e)
upper.tri(b, diag = FALSE)



#Q3.
install.packages("heuristica")
library(heuristica)


#a)
c=matrix(c(952,167,526,3025),nrow = 2,ncol = 2)
dimnames(c)=list(c("positive","Negetive"),c("Positive","Negetive"))
c

#c)
caccu=sum(diag(c))/sum(c)
caccu

#d)
crecall=c[1,1]/sum(c[1,1],c[1,2])
crecall

#e)
cspeci=c[2,2]/sum(c[2,1],c[2,2])
cspeci

#f)
cpre=c[1,1]/sum(c[1,1],c[2,1])
cpre


#Q4.

#a).
d=list("Ayush",32,"Married","Service","Delhi")
d

#b).
d[2]

#c).

d1=d[-2]
d
d1


#d).

d2=d 
d2[2]=31
d2

#Q5.

#a).

Cricketers=data.frame("Name"=c("Sachin","Kapil","Virat","Yuvraj","Raina","Dhoni","Sehewag","Ganguly","Jadeja","Ashwin","Sami","Bhubneshwar","Zahir","Agarkar","Kumble","Shrinath"), "Team"=c("Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind","Ind"), "Type of player"=c("Batsman","All rounder","Batsman","Batsman","Batsman","Batsman/Wicketkeeper","Batsman","Batsman","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler","Bowler"), "No of runs"=c(11000,8000,6000,6000,4000,9000,9000,10000,2000,1000,500,200,100,2000,1000,4000), "No of wickets"=c(50,300,2,80,20,1,2,80,200,250,200,100,300,300,500,350), "Is Captain"=c("No","No","No","No","No","Yes","No","No","No","No","No","No","No","No","No","No"), "Matches Played"=c(50,300,2,80,20,1,2,80,200,250,200,100,300,300,500,350))
View(Cricketers)

#b).
head(Cricketers)

#c).
tail(Cricketers)

#d).
Cricketers[5,]

#e).
Cricketers[,"Team"]

#f).
Cricketers1=Cricketers
Cricketers1=Cricketers2[-5,]
View(Cricketers1)

#g).
Cricketers2=Cricketers
Cricketers2$No.of.runs=NULL
View(Cricketers2)

#g).
Cricketers3=Cricketers
Cricketers3=Cricketers2$Name[]
View(Cricketers3)

#h).
Cricketers4=Cricketers
Cricketers4[15,"No.of.runs"]<-500;Cricketers4

#This function is not wiorking, please suggest.
rbind(Cricketers4,list("Ayush","Ind","Bowler",50,60,"No",25))

View(Cricketers4)
str(Cricketers4)

#Q6.
install.packages('rjson')
library("rjson")
json_file <- "http://api.worldbank.org/country?per_page=10&region=OED&lendingtype=LNX&format=json"
json_data <- fromJSON(file=json_file)
json_data = as.data.frame(json_data)

View(json_data)
